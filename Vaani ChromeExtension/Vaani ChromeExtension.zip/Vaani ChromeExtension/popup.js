//
var config={};

//save in local
$('#sandhi').click(function () {config.sandhi=$("#sandhi").is(':checked'); chrome.storage.local.set({ "vaanieditor-config": config });});
$('#trans').click(function () {config.trans=$("#trans").is(':checked'); chrome.storage.local.set({ "vaanieditor-config": config });});
$('#collo').click(function () {config.collo=$("#collo").is(':checked'); chrome.storage.local.set({ "vaanieditor-config": config });});
$('#api').change(function () {config.api=$("#api").val(); chrome.storage.local.set({ "vaanieditor-config": config });});
$('#active').click(function () {config.status="active"; chrome.storage.local.set({ "vaanieditor-config": config });chrome.runtime.reload();});
$('#inactive').click(function () {config.status="inactive"; chrome.storage.local.set({ "vaanieditor-config": config });chrome.runtime.reload();});

window.onload = function() {
chrome.storage.local.get("vaanieditor-config", function(items){
config=items["vaanieditor-config"];
//console.log(JSON.stringify(config));

if(!config)config={};
if(!config.api )config.api="";
if(typeof config.sandhi == 'undefined')config.sandhi="false";
if(typeof config.trans == 'undefined')config.trans="false";
if(typeof config.collo == 'undefined')config.collo="false";
if(typeof config.status == 'undefined')config.status="inactive";

if(config.api)$("#api").val(config.api);
if(config.sandhi)$("#sandhi").attr('checked',config.sandhi);
if(config.trans)$("#trans").attr('checked',config.trans);
if(config.collo)$("#collo").attr('checked',config.collo);
if(config.status=="active"){$("#active").attr('checked',"true");}
if(config.status=="inactive"){$("#inactive").attr('checked',"true");}
chrome.storage.local.set({ "vaanieditor-config": config });
});
}